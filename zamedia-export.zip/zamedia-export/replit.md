# Overview

ZAmedia is a news portal application built with a modern full-stack architecture. It's a content management system that allows administrators to create, edit, and manage news articles across different categories. The public-facing site displays featured articles, categorized content, and provides a clean reading experience for visitors.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript for type safety
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js for the REST API server
- **Language**: TypeScript throughout the entire stack
- **API Design**: RESTful endpoints for articles and categories
- **Data Storage**: In-memory storage implementation with interface for future database integration
- **Development**: Hot module replacement and middleware for development experience

## Database Design
- **ORM**: Drizzle ORM configured for PostgreSQL with type-safe schema definitions
- **Schema**: Articles and categories with relational structure
- **Migrations**: Drizzle Kit for database schema management
- **Current Implementation**: Memory storage with seed data for development

## Component Architecture
- **UI Components**: Radix UI primitives with custom styling via shadcn/ui
- **Layout**: Responsive design with mobile-first approach
- **Component Structure**: Reusable components for article cards, category sections, headers, and footers
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Content Management
- **Admin Interface**: Dedicated admin routes for content creation and management with authentication
- **Authentication System**: Simple password-based authentication for admin panel protection
- **Article Features**: Support for featured articles, publication status, categories, and rich content
- **Image Handling**: URL-based image management
- **Slug Generation**: Automatic URL-friendly slug creation for articles
- **Admin Security**: Admin panel protected with password authentication (Password: zamedia2025)

## Development Workflow
- **Type Safety**: Shared TypeScript schemas between frontend and backend
- **Hot Reload**: Development server with automatic refresh capabilities
- **Error Handling**: Comprehensive error boundaries and API error management
- **Logging**: Request logging middleware for API monitoring

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL for production data storage
- **Drizzle ORM**: Type-safe database toolkit for PostgreSQL

## UI and Styling
- **Radix UI**: Accessible component primitives for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography

## Development Tools
- **Vite**: Build tool with plugins for React and development enhancements
- **TypeScript**: Type checking and enhanced developer experience
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

## Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation and schema definition
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## State Management
- **TanStack React Query**: Server state management, caching, and synchronization
- **Wouter**: Lightweight routing solution for React applications