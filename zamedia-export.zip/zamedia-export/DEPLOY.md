# 🚀 Panduan Deploy ZAmedia

## 1. Deploy ke Vercel (Gratis & Mudah)

### Persiapan
1. Upload folder `zamedia-export` ke GitHub repository baru
2. Daftar/login ke [vercel.com](https://vercel.com)

### Langkah Deploy
1. **Import Project** di Vercel dashboard
2. **Connect ke GitHub** repository Anda
3. **Build Settings** (otomatis terdeteksi):
   - Framework Preset: `Vite`
   - Root Directory: `./`
   - Build Command: `npm run build`
   - Output Directory: `dist`

4. **Environment Variables** (jika perlu):
   ```
   NODE_ENV=production
   ```

5. **Deploy** - Klik tombol Deploy!

### Hasil
- Mendapat URL: `https://zamedia-[random].vercel.app`
- SSL certificate otomatis
- CDN global
- Domain custom bisa ditambahkan (berbayar)

---

## 2. Deploy ke Railway (Gratis)

### Persiapan
1. Upload ke GitHub
2. Daftar/login ke [railway.app](https://railway.app)

### Langkah Deploy
1. **New Project** → **Deploy from GitHub repo**
2. **Select Repository** ZAmedia
3. **Add Variables** (opsional):
   ```
   PORT=5000
   NODE_ENV=production
   ```
4. **Deploy** otomatis dimulai

### Hasil
- URL: `https://zamedia-production-[random].up.railway.app`
- SSL otomatis
- Database PostgreSQL bisa ditambahkan

---

## 3. Deploy ke Netlify (Gratis)

### Cara Manual
1. Build project lokal:
   ```bash
   npm install
   npm run build
   ```
2. Upload folder `dist` ke Netlify
3. Atur redirect untuk SPA di `_redirects`:
   ```
   /*    /index.html   200
   ```

### Cara GitHub
1. Upload ke GitHub
2. Connect ke Netlify
3. Build settings otomatis

---

## 4. Deploy ke VPS/Server

### Persiapan Server
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2
npm install -g pm2
```

### Deploy Manual
```bash
# Upload file ke server (scp/rsync)
scp -r zamedia-export/ user@server:/var/www/

# Di server
cd /var/www/zamedia-export
npm install
npm run build

# Jalankan dengan PM2
pm2 start server/index.ts --name zamedia
pm2 save
pm2 startup
```

### Setup Nginx (Reverse Proxy)
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 5. Deploy dengan Docker

### Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

EXPOSE 5000
CMD ["npm", "start"]
```

### Deploy
```bash
docker build -t zamedia .
docker run -p 5000:5000 zamedia
```

---

## 🔧 Troubleshooting

### Build Error
- Pastikan semua dependencies terinstall: `npm install`
- Check Node.js version: `node --version` (minimal v16)

### Port Error
- Ubah port di `server/index.ts` jika bentrok
- Set environment variable `PORT`

### Database Error
- Pastikan storage file readable
- Check memory storage initialization

### Frontend Tidak Load
- Pastikan build berhasil: `npm run build`
- Check static file serving di production

---

## 📝 Konfigurasi Production

### Environment Variables
```bash
NODE_ENV=production
PORT=5000
```

### Security Headers
Tambahkan di server:
```javascript
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});
```

---

## 🌐 Domain Custom

Setelah deploy berhasil:
1. **Vercel**: Add domain di project settings
2. **Railway**: Custom domain di dashboard
3. **VPS**: Point A record ke IP server

---

## 📊 Monitoring

### Free Tools:
- **Uptime monitoring**: UptimeRobot
- **Error tracking**: Sentry
- **Analytics**: Google Analytics

### Server monitoring:
```bash
pm2 monit  # Real-time monitoring
pm2 logs   # View logs
```

Selamat deploy! 🎉