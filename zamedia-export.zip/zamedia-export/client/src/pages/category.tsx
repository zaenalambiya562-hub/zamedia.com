import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArticleWithCategory, Category } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ArticleCard from "@/components/article-card";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CategoryPage() {
  const [, params] = useRoute("/category/:slug");
  const slug = params?.slug;

  const { data: category, isLoading: categoryLoading } = useQuery<Category>({
    queryKey: ["/api/categories", slug],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error('Failed to fetch categories');
      const categories = await response.json();
      const category = categories.find((c: Category) => c.slug === slug);
      if (!category) throw new Error('Category not found');
      return category;
    },
    enabled: !!slug,
  });

  const { data: articles = [], isLoading: articlesLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles/category", slug, { published: true }],
    queryFn: async () => {
      const response = await fetch(`/api/articles/category/${slug}?published=true`);
      if (!response.ok) throw new Error('Failed to fetch articles');
      return response.json();
    },
    enabled: !!slug,
  });

  const isLoading = categoryLoading || articlesLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="h-32 bg-muted rounded mb-4"></div>
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded w-20"></div>
                </div>
              ))}
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Kategori Tidak Ditemukan</h1>
            <p className="text-muted-foreground mb-6">Kategori yang Anda cari tidak tersedia.</p>
            <Link href="/">
              <Button>Kembali ke Beranda</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Kembali
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <i className={`${category.icon} text-primary mr-3 zamedia-category-icon`}></i>
            {category.name}
          </h1>
          <p className="text-muted-foreground mt-2">
            Berita terkini dalam kategori {category.name.toLowerCase()}
          </p>
        </div>

        {articles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <div key={article.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <Link href={`/article/${article.slug}`}>
                  <div className="cursor-pointer">
                    {article.imageUrl && (
                      <img 
                        src={article.imageUrl} 
                        alt={article.title}
                        className="w-full h-48 object-cover"
                      />
                    )}
                    <div className="p-4">
                      <h3 className="text-lg font-medium text-foreground leading-tight mb-2">
                        {article.title}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-3 line-clamp-3">
                        {article.excerpt}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(article.publishedAt!).toLocaleDateString('id-ID', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h2 className="text-xl font-medium text-foreground mb-2">Belum Ada Artikel</h2>
            <p className="text-muted-foreground">Belum ada artikel yang dipublikasikan dalam kategori ini.</p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
