import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import Header from "@/components/header";
import Footer from "@/components/footer";
import FeaturedArticle from "@/components/featured-article";
import CategorySection from "@/components/category-section";

export default function Home() {
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <FeaturedArticle />
        
        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                <div className="h-6 bg-muted rounded mb-6"></div>
                <div className="space-y-4">
                  {[1, 2, 3].map((j) => (
                    <div key={j} className="flex space-x-4">
                      <div className="w-16 h-12 bg-muted rounded"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-3 bg-muted rounded w-20"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {categories.slice(0, 3).map((category) => (
                <CategorySection key={category.id} category={category} />
              ))}
            </div>

            {categories.length > 3 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                {categories.slice(3).map((category) => (
                  <CategorySection key={category.id} category={category} size="medium" />
                ))}
              </div>
            )}
          </>
        )}
      </main>
      
      <Footer />
    </div>
  );
}
