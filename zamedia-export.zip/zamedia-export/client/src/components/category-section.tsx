import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArticleWithCategory, Category } from "@shared/schema";
import ArticleCard from "./article-card";

interface CategorySectionProps {
  category: Category;
  size?: "small" | "medium";
}

export default function CategorySection({ category, size = "small" }: CategorySectionProps) {
  const { data: articles = [], isLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles/category", category.slug, { published: true }],
    queryFn: async () => {
      const response = await fetch(`/api/articles/category/${category.slug}?published=true`);
      if (!response.ok) throw new Error('Failed to fetch articles');
      return response.json();
    },
  });

  const limitedArticles = articles.slice(0, size === "medium" ? 2 : 3);

  if (isLoading) {
    return (
      <section className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="h-6 bg-muted rounded w-24"></div>
          <div className="h-4 bg-muted rounded w-20"></div>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex space-x-4">
              <div className="w-16 h-12 bg-muted rounded"></div>
              <div className="flex-1">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-3 bg-muted rounded w-20"></div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-foreground flex items-center">
          <i className={`${category.icon} text-primary mr-2 zamedia-category-icon`}></i>
          {category.name}
        </h2>
        <Link href={`/category/${category.slug}`} className="text-primary hover:text-primary/80 text-sm font-medium">
          Lihat Semua
        </Link>
      </div>
      
      <div className="space-y-0">
        {limitedArticles.length > 0 ? (
          limitedArticles.map((article) => (
            <ArticleCard key={article.id} article={article} size={size} />
          ))
        ) : (
          <p className="text-muted-foreground text-sm py-4">Belum ada artikel dalam kategori ini.</p>
        )}
      </div>
    </section>
  );
}
