import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Facebook, Twitter, Instagram, Youtube, Heart } from "lucide-react";

export default function Footer() {
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return (
    <footer className="bg-neutral-900 text-neutral-300 mt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <span className="text-2xl font-bold text-white">ZAmedia</span>
            </div>
            <p className="text-neutral-400 mb-4 leading-relaxed">
              Portal berita terpercaya yang menyajikan informasi terkini dengan integritas dan objektivitas tinggi untuk membangun Indonesia yang lebih baik.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Kategori</h3>
            <ul className="space-y-2">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link href={`/category/${category.slug}`} className="text-neutral-400 hover:text-white transition-colors">
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Informasi</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Tentang Kami</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Kontak</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Kebijakan Privasi</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Syarat & Ketentuan</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-neutral-400 text-sm">
              © 2025 ZAmedia. Seluruh hak cipta dilindungi.
            </p>
            <p className="text-neutral-400 text-sm mt-2 md:mt-0 flex items-center">
              Dibuat dengan <Heart className="h-4 w-4 text-accent mx-1 fill-current" /> untuk Indonesia
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
