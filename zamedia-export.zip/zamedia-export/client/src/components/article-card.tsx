import { Link } from "wouter";
import { ArticleWithCategory } from "@shared/schema";
import { formatDate } from "@/lib/utils";

interface ArticleCardProps {
  article: ArticleWithCategory;
  size?: "small" | "medium" | "large";
}

export default function ArticleCard({ article, size = "small" }: ArticleCardProps) {
  if (size === "large") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer">
          <div className="md:flex">
            <div className="md:w-2/3">
              {article.imageUrl && (
                <img 
                  src={article.imageUrl} 
                  alt={article.title}
                  className="w-full h-64 md:h-80 object-cover"
                />
              )}
            </div>
            <div className="md:w-1/3 p-6">
              <div className="flex items-center mb-3">
                <span className="bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium">
                  UTAMA
                </span>
                <span className="ml-3 text-muted-foreground text-sm">
                  {formatDate(article.publishedAt!)}
                </span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-4 leading-tight zamedia-article-title">
                {article.title}
              </h1>
              <p className="text-muted-foreground text-lg leading-relaxed mb-4">
                {article.excerpt}
              </p>
              <span className="inline-flex items-center text-primary hover:text-primary/80 font-medium transition-colors">
                Baca Selengkapnya
              </span>
            </div>
          </div>
        </article>
      </Link>
    );
  }

  if (size === "medium") {
    return (
      <Link href={`/article/${article.slug}`}>
        <article className="flex space-x-4 pb-4 mb-4 border-b border-border last:border-b-0 last:pb-0 last:mb-0 hover:bg-muted/50 rounded p-2 transition-colors cursor-pointer">
          {article.imageUrl && (
            <img 
              src={article.imageUrl} 
              alt={article.title}
              className="w-20 h-14 rounded object-cover flex-shrink-0"
            />
          )}
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-medium text-foreground leading-tight mb-2">
              {article.title}
            </h3>
            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
              {article.excerpt}
            </p>
            <p className="text-xs text-muted-foreground">
              {formatDate(article.publishedAt!)}
            </p>
          </div>
        </article>
      </Link>
    );
  }

  return (
    <Link href={`/article/${article.slug}`}>
      <article className="flex space-x-4 pb-4 mb-4 border-b border-border last:border-b-0 last:pb-0 last:mb-0 hover:bg-muted/50 rounded p-2 transition-colors cursor-pointer">
        {article.imageUrl && (
          <img 
            src={article.imageUrl} 
            alt={article.title}
            className="w-16 h-12 rounded object-cover flex-shrink-0"
          />
        )}
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-medium text-foreground leading-tight mb-1">
            {article.title}
          </h3>
          <p className="text-xs text-muted-foreground">
            {formatDate(article.publishedAt!)}
          </p>
        </div>
      </article>
    </Link>
  );
}
