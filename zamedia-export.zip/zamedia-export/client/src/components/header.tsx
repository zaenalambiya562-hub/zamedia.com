import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const isAdmin = location.startsWith("/admin");

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    enabled: !isAdmin,
  });

  if (isAdmin) {
    return (
      <header className="bg-white shadow-sm border-b border-border sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/admin" className="text-2xl font-bold text-primary hover:text-primary/80 transition-colors">
              ZAmedia Admin
            </Link>
            <nav className="flex items-center space-x-6">
              <Link href="/admin" className="text-foreground hover:text-primary transition-colors font-medium">
                Dashboard
              </Link>
              <Link href="/admin/create" className="text-foreground hover:text-primary transition-colors font-medium">
                Tulis Artikel
              </Link>
              <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
                Lihat Situs
              </Link>
            </nav>
          </div>
        </div>
      </header>
    );
  }

  return (
    <header className="bg-white shadow-sm border-b border-border sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="text-2xl font-bold text-primary hover:text-primary/80 transition-colors">
            ZAmedia
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
              Beranda
            </Link>
            {categories.map((category) => (
              <Link
                key={category.id}
                href={`/category/${category.slug}`}
                className="text-foreground hover:text-primary transition-colors font-medium"
              >
                {category.name}
              </Link>
            ))}
            <Link href="/admin" className="text-accent hover:text-accent/80 transition-colors font-medium">
              Admin
            </Link>
          </nav>
          
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col space-y-4 mt-6">
                <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
                  Beranda
                </Link>
                {categories.map((category) => (
                  <Link
                    key={category.id}
                    href={`/category/${category.slug}`}
                    className="text-foreground hover:text-primary transition-colors font-medium"
                  >
                    {category.name}
                  </Link>
                ))}
                <Link href="/admin" className="text-accent hover:text-accent/80 transition-colors font-medium">
                  Admin
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
