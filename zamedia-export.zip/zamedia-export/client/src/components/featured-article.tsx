import { useQuery } from "@tanstack/react-query";
import { ArticleWithCategory } from "@shared/schema";
import ArticleCard from "./article-card";

export default function FeaturedArticle() {
  const { data: featuredArticle, isLoading } = useQuery<ArticleWithCategory | null>({
    queryKey: ["/api/articles/featured"],
  });

  if (isLoading) {
    return (
      <section className="mb-12">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden animate-pulse">
          <div className="md:flex">
            <div className="md:w-2/3">
              <div className="w-full h-64 md:h-80 bg-muted"></div>
            </div>
            <div className="md:w-1/3 p-6">
              <div className="h-6 bg-muted rounded mb-3"></div>
              <div className="h-8 bg-muted rounded mb-4"></div>
              <div className="h-20 bg-muted rounded mb-4"></div>
              <div className="h-4 bg-muted rounded w-32"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (!featuredArticle) {
    return null;
  }

  return (
    <section className="mb-12">
      <ArticleCard article={featuredArticle} size="large" />
    </section>
  );
}
