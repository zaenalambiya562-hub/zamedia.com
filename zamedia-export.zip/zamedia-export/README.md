# ZAmedia - Portal Berita Indonesia

Portal berita modern dengan dashboard admin yang aman. Tampilan mirip Kompas.com dengan fitur lengkap untuk mengelola konten berita.

## 🚀 Fitur Utama

### Website Publik
- **Tampilan Profesional**: Desain mirip Kompas.com yang bersih dan mudah dibaca
- **Responsive Design**: Tampil sempurna di desktop, tablet, dan mobile
- **Kategori Berita**: Politik, Ekonomi, Teknologi, Olahraga, Hiburan
- **Artikel Utama**: Fitur highlight artikel penting di beranda
- **SEO Friendly**: URL slug otomatis dan struktur yang SEO-optimized

### Dashboard Admin
- **Keamanan**: Login dengan password untuk melindungi admin panel
- **Manajemen Artikel**: CRUD lengkap untuk artikel (Create, Read, Update, Delete)
- **Editor Konten**: Form yang user-friendly untuk menulis artikel
- **Status Publikasi**: Kontrol artikel draft/published dan featured
- **Dashboard Analytics**: Overview statistik artikel

## 🛠️ Teknologi

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: In-memory storage (mudah upgrade ke PostgreSQL)
- **UI Components**: Radix UI + shadcn/ui
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query
- **Form Handling**: React Hook Form + Zod validation

## 📦 Instalasi

1. **Clone atau download project**
```bash
git clone <repo-url>
cd zamedia-export
```

2. **Install dependencies**
```bash
npm install
```

3. **Jalankan development server**
```bash
npm run dev
```

4. **Akses aplikasi**
- Website publik: http://localhost:5000
- Admin panel: http://localhost:5000/admin

## 🔐 Login Admin

- **URL**: `/admin`
- **Password**: `zamedia2025`

## 📁 Struktur Project

```
zamedia-export/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/     # UI Components
│   │   ├── pages/         # Page components
│   │   ├── hooks/         # Custom hooks
│   │   └── lib/           # Utilities
│   └── index.html
├── server/                 # Backend Express
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Data storage
│   └── vite.ts            # Vite integration
├── shared/                 # Shared types
│   └── schema.ts          # Database schema
└── package.json
```

## 🚀 Deploy ke Production

### Vercel (Gratis)
1. Push ke GitHub
2. Connect ke Vercel
3. Deploy otomatis

### Railway (Gratis)
1. Push ke GitHub
2. Connect ke Railway
3. Deploy otomatis

### VPS Manual
```bash
npm run build
npm start
```

## 🔧 Kustomisasi

### Mengganti Password Admin
Edit file `client/src/components/admin-auth.tsx`:
```typescript
const ADMIN_PASSWORD = "password-baru-anda";
```

### Menambah Kategori Baru
Edit file `server/storage.ts` di bagian `seedData()`:
```typescript
const categoryData = [
  // ... kategori existing
  { name: "Kategori Baru", slug: "kategori-baru", icon: "fas fa-icon" },
];
```

### Mengubah Database ke PostgreSQL
1. Install drizzle-kit: `npm install drizzle-kit`
2. Setup database di `drizzle.config.ts`
3. Replace `MemStorage` dengan database adapter

## 📝 Cara Pakai

### Menulis Artikel Baru
1. Login ke `/admin` dengan password `zamedia2025`
2. Klik "Tulis Artikel Baru"
3. Isi form dengan:
   - Judul artikel
   - Ringkasan (excerpt)
   - Konten lengkap
   - URL gambar (opsional)
   - Kategori
   - Status publikasi
   - Featured (artikel utama)
4. Klik "Simpan Artikel"

### Mengelola Artikel
- **Edit**: Klik tombol edit di dashboard
- **Hapus**: Klik tombol hapus (konfirmasi required)
- **Publikasi**: Toggle status published/draft
- **Featured**: Jadikan artikel utama di beranda

## 🎨 Kustomisasi Tampilan

### Mengubah Warna
Edit file `client/src/index.css` bagian CSS variables:
```css
:root {
  --primary: hsl(220 91% 38%);    /* Warna utama */
  --accent: hsl(356 70% 45%);     /* Warna aksen */
  /* ... */
}
```

### Mengubah Font
Edit file `client/src/index.css`:
```css
:root {
  --font-sans: 'Font Pilihan Anda', Inter, system-ui, sans-serif;
}
```

## 🌐 Domain Custom

Setelah deploy, Anda bisa menambahkan domain custom:
1. **Vercel**: Add domain di dashboard
2. **Railway**: Add custom domain
3. **VPS**: Setup nginx/apache

## 📞 Support

Jika ada pertanyaan atau butuh bantuan kustomisasi, silakan buat issue atau hubungi developer.

## 📄 Lisensi

MIT License - Bebas digunakan untuk personal maupun komersial.

---

**ZAmedia** - Portal berita Indonesia yang modern dan profesional 🇮🇩