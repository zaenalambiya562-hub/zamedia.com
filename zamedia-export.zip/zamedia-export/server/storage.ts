import { type Category, type InsertCategory, type Article, type InsertArticle, type UpdateArticle, type ArticleWithCategory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Articles
  getArticles(published?: boolean): Promise<ArticleWithCategory[]>;
  getArticlesByCategory(categorySlug: string, published?: boolean): Promise<ArticleWithCategory[]>;
  getArticleBySlug(slug: string, published?: boolean): Promise<ArticleWithCategory | undefined>;
  getFeaturedArticle(): Promise<ArticleWithCategory | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: string, article: UpdateArticle): Promise<Article | undefined>;
  deleteArticle(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private categories: Map<string, Category>;
  private articles: Map<string, Article>;

  constructor() {
    this.categories = new Map();
    this.articles = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed categories
    const categoryData = [
      { name: "Politik", slug: "politik", icon: "fas fa-landmark" },
      { name: "Ekonomi", slug: "ekonomi", icon: "fas fa-chart-line" },
      { name: "Teknologi", slug: "teknologi", icon: "fas fa-microchip" },
      { name: "Olahraga", slug: "olahraga", icon: "fas fa-futbol" },
      { name: "Hiburan", slug: "hiburan", icon: "fas fa-film" },
    ];

    const categories: Category[] = [];
    categoryData.forEach(cat => {
      const id = randomUUID();
      const category: Category = { ...cat, id };
      this.categories.set(id, category);
      categories.push(category);
    });

    // Seed sample articles
    const sampleArticles = [
      {
        title: "Pemerintah Luncurkan Program Digitalisasi UMKM Nasional",
        excerpt: "Program ambisius pemerintah untuk mengdigitalkan seluruh UMKM di Indonesia dimulai tahun ini dengan target 10 juta UMKM.",
        content: "Jakarta - Pemerintah Indonesia hari ini resmi meluncurkan Program Digitalisasi UMKM Nasional yang menargetkan transformasi digital 10 juta usaha mikro, kecil, dan menengah (UMKM) dalam tiga tahun ke depan.\n\nProgram ini merupakan bagian dari upaya pemerintah untuk memperkuat ekonomi digital Indonesia dan meningkatkan daya saing UMKM di era modern. Melalui program ini, UMKM akan mendapatkan akses ke platform digital, pelatihan teknologi, dan bantuan modal usaha.\n\nMenteri Koperasi dan UKM menyatakan bahwa program ini akan memberikan dampak signifikan bagi perekonomian nasional. 'Kami optimis bahwa dengan transformasi digital ini, UMKM Indonesia dapat bersaing di pasar global,' ujarnya dalam konferensi pers di Jakarta.\n\nProgram ini akan dilaksanakan secara bertahap, dimulai dari kota-kota besar kemudian diperluas ke seluruh Indonesia. Para pelaku UMKM dapat mendaftar melalui portal resmi yang telah disediakan pemerintah.",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800",
        categoryId: categories.find(c => c.slug === 'politik')?.id || '',
        isFeatured: true,
        isPublished: true,
      },
      {
        title: "Bursa Efek Indonesia Catat Rekor Transaksi Harian Tertinggi",
        excerpt: "Transaksi harian di BEI mencapai Rp 15,8 triliun, menandai momentum positif pasar modal Indonesia di awal tahun.",
        content: "Jakarta - Bursa Efek Indonesia (BEI) mencatat rekor transaksi harian tertinggi sepanjang sejarah dengan nilai mencapai Rp 15,8 triliun pada perdagangan hari ini.\n\nLonjakan transaksi ini didorong oleh optimisme investor terhadap prospek ekonomi Indonesia di tahun ini, serta masuknya dana asing yang signifikan ke pasar saham domestik.\n\nDirektur Utama BEI menyampaikan bahwa pencapaian ini mencerminkan kepercayaan investor terhadap fundamental ekonomi Indonesia yang semakin kuat. 'Ini adalah sinyal positif bahwa pasar modal Indonesia semakin mature dan menarik bagi investor global,' katanya.\n\nBeberapa sektor yang menjadi favorit investor antara lain teknologi, perbankan, dan komoditas. Indeks Harga Saham Gabungan (IHSG) juga menguat 2,3% di penutupan perdagangan hari ini.",
        imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800",
        categoryId: categories.find(c => c.slug === 'ekonomi')?.id || '',
        isFeatured: false,
        isPublished: true,
      },
      {
        title: "Startup Indonesia Raih Pendanaan Seri A Sebesar $50 Juta",
        excerpt: "Startup teknologi finansial asal Indonesia berhasil meraih pendanaan besar dari investor regional untuk ekspansi bisnis.",
        content: "Jakarta - Sebuah startup teknologi finansial (fintech) asal Indonesia berhasil meraih pendanaan Seri A sebesar 50 juta dollar AS dari konsorsium investor regional.\n\nPendanaan ini akan digunakan untuk mempercepat ekspansi produk dan jangkauan pasar, terutama di kawasan Asia Tenggara. Startup ini fokus pada layanan pembayaran digital dan pinjaman online untuk UMKM.\n\nCEO startup tersebut menyatakan bahwa pendanaan ini merupakan validasi atas model bisnis yang telah mereka kembangkan. 'Kami akan menggunakan dana ini untuk mengembangkan teknologi AI dan machine learning yang lebih canggih,' ungkapnya.\n\nIndonesia semakin dikenal sebagai salah satu ekosistem startup terbesar di Asia Tenggara, dengan berbagai unicorn yang telah lahir dari negeri ini.",
        imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800",
        categoryId: categories.find(c => c.slug === 'teknologi')?.id || '',
        isFeatured: false,
        isPublished: true,
      },
      {
        title: "Timnas Indonesia Lolos ke Piala Asia 2025",
        excerpt: "Setelah pertandingan dramatis, timnas Indonesia berhasil mengamankan tiket ke Piala Asia dengan kemenangan 2-1 atas Thailand.",
        content: "Bangkok - Timnas Indonesia berhasil mengamankan tiket ke Piala Asia 2025 setelah mengalahkan Thailand dengan skor 2-1 dalam pertandingan kualifikasi yang berlangsung dramatis di Stadium Rajamangala, Bangkok.\n\nPertandingan dimulai dengan Thailand yang unggul terlebih dahulu di menit ke-23. Namun, Indonesia mampu membalas melalui gol cantik di menit ke-67, sebelum akhirnya mencetak gol kemenangan di injury time.\n\nPelatih timnas Indonesia menyatakan bahwa ini adalah hasil dari kerja keras seluruh tim dalam beberapa bulan terakhir. 'Para pemain menunjukkan mentalitas juang yang luar biasa, dan ini adalah pencapaian bersejarah bagi sepak bola Indonesia,' katanya.\n\nDengan lolos ke Piala Asia 2025, Indonesia akan bertemu dengan tim-tim terbaik di Asia dan berkesempatan untuk menunjukkan kualitas sepak bola nasional di panggung internasional.",
        imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800",
        categoryId: categories.find(c => c.slug === 'olahraga')?.id || '',
        isFeatured: false,
        isPublished: true,
      },
      {
        title: "Film Indonesia Raih Penghargaan di Festival Film Internasional",
        excerpt: "Film drama Indonesia 'Senja di Kampung' meraih Best Director Award di Festival Film Cannes, mengharumkan nama Indonesia di dunia perfilman.",
        content: "Cannes - Film Indonesia berjudul 'Senja di Kampung' berhasil meraih penghargaan Best Director Award di Festival Film Cannes, menandai pencapaian membanggakan bagi industri perfilman Indonesia.\n\nFilm yang disutradarai oleh sutradara muda Indonesia ini mengisahkan kehidupan masyarakat pedesaan dengan latar belakang perubahan zaman yang pesat. Film ini mendapat apresiasi tinggi dari kritikus internasional karena sinematografi yang indah dan cerita yang menyentuh hati.\n\nSutradara film tersebut menyampaikan rasa syukurnya atas pencapaian ini. 'Ini adalah kemenangan untuk seluruh industri film Indonesia. Kami membuktikan bahwa cerita lokal bisa berresonansi dengan audiens global,' ujarnya dalam pidato penerimaan penghargaan.\n\nPencapaian ini diharapkan dapat membuka jalan bagi lebih banyak film Indonesia untuk go international dan mengangkat citra positif Indonesia di mata dunia.",
        imageUrl: "https://images.unsplash.com/photo-1489599904472-84978845072e?w=800",
        categoryId: categories.find(c => c.slug === 'hiburan')?.id || '',
        isFeatured: false,
        isPublished: true,
      }
    ];

    sampleArticles.forEach(articleData => {
      const id = randomUUID();
      const slug = this.generateSlug(articleData.title);
      const now = new Date();
      
      const article: Article = {
        id,
        title: articleData.title,
        slug,
        excerpt: articleData.excerpt,
        content: articleData.content,
        imageUrl: articleData.imageUrl,
        categoryId: articleData.categoryId,
        isPublished: articleData.isPublished,
        isFeatured: articleData.isFeatured,
        publishedAt: articleData.isPublished ? now : null,
        createdAt: now,
        updatedAt: now,
      };
      
      this.articles.set(id, article);
    });
  }

  private generateSlug(title: string): string {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(cat => cat.slug === slug);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  async getArticles(published?: boolean): Promise<ArticleWithCategory[]> {
    const articles = Array.from(this.articles.values());
    const filtered = published !== undefined 
      ? articles.filter(article => article.isPublished === published)
      : articles;
    
    return filtered
      .map(article => {
        const category = this.categories.get(article.categoryId);
        return category ? { ...article, category } : null;
      })
      .filter((article): article is ArticleWithCategory => article !== null)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getArticlesByCategory(categorySlug: string, published?: boolean): Promise<ArticleWithCategory[]> {
    const category = await this.getCategoryBySlug(categorySlug);
    if (!category) return [];

    const articles = Array.from(this.articles.values());
    const filtered = articles.filter(article => {
      const matchesCategory = article.categoryId === category.id;
      const matchesPublished = published !== undefined ? article.isPublished === published : true;
      return matchesCategory && matchesPublished;
    });

    return filtered
      .map(article => ({ ...article, category }))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getArticleBySlug(slug: string, published?: boolean): Promise<ArticleWithCategory | undefined> {
    const article = Array.from(this.articles.values()).find(article => {
      const matchesSlug = article.slug === slug;
      const matchesPublished = published !== undefined ? article.isPublished === published : true;
      return matchesSlug && matchesPublished;
    });

    if (!article) return undefined;

    const category = this.categories.get(article.categoryId);
    return category ? { ...article, category } : undefined;
  }

  async getFeaturedArticle(): Promise<ArticleWithCategory | undefined> {
    const article = Array.from(this.articles.values()).find(
      article => article.isFeatured && article.isPublished
    );

    if (!article) return undefined;

    const category = this.categories.get(article.categoryId);
    return category ? { ...article, category } : undefined;
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = randomUUID();
    const slug = this.generateSlug(insertArticle.title);
    const now = new Date();
    
    const article: Article = {
      ...insertArticle,
      id,
      slug,
      publishedAt: insertArticle.isPublished ? now : null,
      createdAt: now,
      updatedAt: now,
    };

    this.articles.set(id, article);
    return article;
  }

  async updateArticle(id: string, updateArticle: UpdateArticle): Promise<Article | undefined> {
    const existing = this.articles.get(id);
    if (!existing) return undefined;

    const updatedSlug = updateArticle.title ? this.generateSlug(updateArticle.title) : existing.slug;
    const now = new Date();
    
    const publishedAt = updateArticle.isPublished !== undefined
      ? updateArticle.isPublished ? (existing.publishedAt || now) : null
      : existing.publishedAt;

    const article: Article = {
      ...existing,
      ...updateArticle,
      slug: updatedSlug,
      publishedAt,
      updatedAt: now,
    };

    this.articles.set(id, article);
    return article;
  }

  async deleteArticle(id: string): Promise<boolean> {
    return this.articles.delete(id);
  }
}

export const storage = new MemStorage();
